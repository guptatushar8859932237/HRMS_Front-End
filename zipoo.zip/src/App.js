import React from "react"

import Login from "./component/loginform";
import { BrowserRouter, Routes , Route } from "react-router-dom";
import Home from "./Home";
import Attendence from "./Attendence";
import AttendenceSummary from "./component/AttendenceSummary";
import SideMenu from "./component/sidebarnavbar";
import LeaveApplication from "./LeaveApplication";
import LeaveBalance from "./LeaveBalance";
import Holiday from "./holiday";
import Grivirnce from "./component/grivience";
import Reimbursement from "./Reimbursement";
import Dailyreport from "./component/dailyReport";
import Userform from "./Userform";
import Userdata from "./Userdata";
import Travell from "./component/travell";
import Dashboard from "./component/profile";
export default function App() {
 return (
  <>
                                         
<BrowserRouter>
<Routes>
<Route path="" element={<Login />} />

<Route path="/dashboard" element={<SideMenu />} >
<Route path="" element={<Home />} /> 

<Route path="AttendenceSummary" element={<AttendenceSummary />} />
<Route path="Attendence" element={<Attendence />} />
<Route path="LeaveApplication" element={<LeaveApplication />} />
<Route path="LeaveBalance" element={<LeaveBalance />} />
<Route path="holiday" element={<Holiday />} />
<Route path="Grivience" element={<Grivirnce />} />
<Route path="Reimbursement" element={<Reimbursement />} />
<Route path="DailyReport" element={<Dailyreport />} />
<Route path="Userform" element={<Userform />} />
<Route path="USerdata" element={<Userdata />} />
<Route path="dashboard" element={<Dashboard />} />
<Route path="Travell" element={<Travell />} />

</Route>

</Routes>
</BrowserRouter>   

    </>
  );
}

