import React from "react"
import "./girivience.css"
export default function Grivirnce(){
    return(
        <>
        <div class="container-fluid">
            <div class="row">
                <div class="col">

                <div class="container">
  <div class="row">
    <div class="col-sm">
       <h5 class="col-12">name</h5>
       <input class="col-10"></input>
    </div>
    <div class="col-sm">
      <h5 class="col-12">type</h5>
      <input class="col-10"></input>

    </div>
    <div class="col-sm">
      <h5 class="col-12">Complaint description</h5>
      <input class="col-10" ></input> 

    </div>
    <div class="col-sm">
   <h5 class="col-12">   Complaint Date</h5>
      <input class="col-10"></input>
    
    </div>
  </div>
</div>
                </div>
            </div>
        </div>
        </>
    )
}