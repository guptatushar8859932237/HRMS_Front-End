import React from "react"
import  "./profile.css"
import Dashboardgraph from "./dashboardgraph"

export default  function Dashboard(){
  

    return(
        <>
       
      <div class="container-fuild">
        <div class="row mb-3">
          <div class="col-lg-3 col-sm-6 mb-2 colcont">
            <div class=" aaaa4 p-2">
              <div class="col-12">
                <span className="font">125 <i class="bi bi-person-lines-fill ml-3"></i> </span>
              </div>
              <div class="col-12">
                <span className="font1">Total employee</span>
              </div>

            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-2 colcont">
            <div class="aaaa1 p-2">
              <div class="col-12">
                <span className="font">75</span>
              </div>
              <div class="col-12">
                <span className="font1">Active Employee</span>
              </div>

            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-2 colcont">

            <div class="aaaa2 p-2">
              <div class="col-12">

                <span className="font">109</span>
              </div>
              <div class="col-12">

                <span className="font1">Registerd Employee</span>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-2 colcont">
            <div class="aaaa3 p-2">
              <div class="col-12">

                <span className="font">25</span>
              </div>
              <div class="col-12">

                <span className="font1">Leave</span>
              </div>
            </div>
          </div>

        </div>
      </div>

<Dashboardgraph />

        </>
    )
}