import React from "react"
import "./dailyreport.css"
export default function Dailyreport(){
    return(
        <>
        <div class="container-fluid">
  <div class="row">
    <div class="col bordercolmn">
      <h2> <i class="bi bi-list-check"></i>Daily Reports Detail's</h2>
<button class="btn btn-danger">Home</button>
    </div>
  
  </div>
</div>


<h5 class="pt-5">Task Detail's</h5>
<div class="container-fluid">
  <div class="row p-3">
    <div class="col">
  <div class="row">
    <div class="col">
        <textarea class="col-12 textplace" placeholder="How to add task with the help of HRMS."></textarea>
        
        </div>
        </div>
        </div>
        </div>
        </div>
        <div class="container-fluid">
  <div class="row ">
    <div class="col">
      <h7>Time Taken</h7>
      <input class="col-10"></input>
    </div>
    <div class="col">
    <h7>Assigned By</h7>
      <input class="col-10"></input>
    </div>
    <div class="col">
      <h7>Remark</h7>
      <input class="col-10"></input>
    </div>
 
    <div class="col">
      <h9>Report Date</h9>
      <input class="col-10"></input>
    </div>

    <div class="col pt-5 buttonend">
      <button class="btn btn-primary ">Save Report</button>
    </div>
  </div>
</div>
        
        
        </>
    )
}