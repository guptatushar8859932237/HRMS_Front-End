import React from "react"
import "./travell.css"

export default function Travell(){
    return(
        <>

        <div class="container-fluid">
            <div class="row borderrow">
                <div class="col">
                <h3><i class="bi bi-airplane-fill px-3"></i> My Request</h3>
                </div>
            </div>
        </div>
        <div class="container-fluid">
  <div class="row pt-5">
    <div class="col">
      Travell Type
      <input></input>
    </div>
    <div class="col">
      Purpose
  <input></input>
    </div>
    <div class="col">
      Travell From Date
  <input type="date" class="col-10"></input>
    </div>
  </div>
</div>
<div class="container-fluid">
  <div class="row pt-3">
    <div class="col">
      Travell To Date
      <input type="date" class="col-10"></input>
    </div>
    <div class="col">
      Created Date
  <input type="date" class="col-10"></input>
  </div>
    <div class="col">
    <button class="btncolor mt-3 col-10"> create new request</button>
  </div> 
   </div>
</div>

        </>
    )
}