import React, { useState } from "react"
import "./login.css"

// import Profile from "./Profileimage "
// import { useNavigate } from "react-router-dom"

export default function Login() {

    const [logind , setLogind]=useState(" ")
    const [error , setError]=useState({})
// const navigate=useNavigate()

 const loginde=(e)=>{
    const{name , value}=e.target
    setLogind({...logind , [name] :value})
 }

 const handlevali=(value)=>{
   let error={}
if(!value.email){
    error.email="email is required"
}
if(!value.password){
    value.password="password is required"
}
else{
   console.log("hellow")
}
setError(error)
 }

const logindata=()=>{
    handlevali(logind)
    console.log('chk logindata',logind)
}


    return (
        <>
            <div class="container-fluid bagimg">
                <div class="row">
                    <div class="col-md-4">
                    </div>
                    <div class=" col-md-4 formclass">
                        <div class="card">
                            <div className="row">
                                <div class="col-8 logo">
                                </div>
                                <div class="col-12">
                                    <h3 align="center">User Can Login Here</h3>
                                </div>
                            </div>
                            <form className="formpadding">
                                <div >
                                    <label htmlFor="exampleInputEmail1" class="form-label"  >Email address</label>
                                    <input type="email" class="form-control" name="email"  onChange={loginde}  id="exampleInputEmail1"  aria-describedby="emailHelp" />
                               {error.email}
                                </div>
                                <div>
                                <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" onChange={loginde} name="password" placeholder="Password" />
  </div>

                                    {/* <label htmlFor="exampleInputPassword1" class="form-label">Password</label> */}
                                    {/* <input type="password" class="form-control"  name="password"  onChange={loginde}  id="exampleInputPassword1" /> */}
                                {error.password}
                                </div>
                                <button type="button" class=" btn btn-primary buttonsal" onClick={logindata} >Login </button>
                                <p className="forgot" class="mb-3" >forgot password</p>
                            </form>
                        </div>
                    </div>
                    <div class="col-md-4">
                       
                    </div>
                </div>
            </div>
        </>
    )
}


