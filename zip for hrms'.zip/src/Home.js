
import React from "react"
import "./App.css"


export default function Home() {
  return (
    <>


      <div class="container-fuild">
        <div class="row mb-3">
          <div class="col-lg-3 col-sm-6 mb-2 colcont">
            <div class=" aaaa4 p-2">
              <div class="col-12">
                <span className="font">2</span>
              </div>
              <div class="col-12">
                <span className="font1">Attendence</span>
              </div>

            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-2 colcont">
            <div class="aaaa1 p-2">
              <div class="col-12">
                <span className="font">2</span>
              </div>
              <div class="col-12">
                <span className="font1">Daily Report</span>
              </div>

            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-2 colcont">

            <div class="aaaa2 p-2">
              <div class="col-12">

                <span className="font">2</span>
              </div>
              <div class="col-12">

                <span className="font1">Leave taken</span>
              </div>
            </div>
          </div>
          <div class="col-lg-3 col-sm-6 mb-2 colcont">
            <div class="aaaa3 p-2">
              <div class="col-12">

                <span className="font">2</span>
              </div>
              <div class="col-12">

                <span className="font1">Holiday</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      <p class="lead"><div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <h2>Profile Detail</h2>
          </div>

        </div>
      </div></p>
      <hr />
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-4">
            <img src={require('../src/component/hrmsimage.jpg')} alt="logo" width="100%" />


          </div>
          <div class="col-md-8 d-flex">
            <table class="table table table-striped tblecol">

              <tbody>
                <tr>
                  <th scope="row">Employee Code</th>
                  <td>02013033510</td>
                </tr>
                <tr>
                  <th scope="row">Designation</th>

                  <td>Software developer</td>
                </tr>
                <tr>
                  <th scope="row">Employee Name</th>

                  <td>Tushar Gupta</td>
                </tr>
                <tr>
                  <th scope="row">Gender</th>

                  <td>Male</td>
                </tr>
                <tr>
                  <th scope="row">DOB</th>

                  <td>11/07/2000</td>
                </tr>
                <tr>
                  <th scope="row">Mobile No</th>

                  <td>8859932237</td>
                </tr>
                <tr>
                  <th scope="row">Email i'd</th>

                  <td>tushargupta8859@gmail.com</td>
                </tr>
                <tr>
                  <th scope="row">Employee Name</th>

                  <td>Tushar Gupta</td>
                </tr>


              </tbody>
            </table>
          </div>
        </div>
      </div>




    </>)
}

