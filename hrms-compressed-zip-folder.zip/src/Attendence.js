import React from "react"
import "./attendence.css"

export default function Attendence() {

  return (
    <>
      <div class="container-fuild">
        <div class="row mb-3">
          <div class="col-lg-12 mb-2 colcont">

            <table class="table border12">
              <thead>
                <tr class="table-primary">
                  <th scope="col contbox">Employee Code</th>
                  <th>2012012012</th>
                  <th scope="col">Employee Name</th>
                  <th>Tushar Gupta</th>
                </tr>
              </thead>
              <tbody>
                <tr >
                  <th scope="row">Mobile Number</th>
                  <td className="uiname">8859932237</td>
                  <th scope="col" className="uiname">Email i'd</th>
                  <td className="uiname">tushargupta8859@gmail.com</td>
                </tr>

              </tbody>
            </table>

          </div>
        </div>
      </div>
      <div class="container-fuild border12">
        <div class="row">
          <div class="col-6">

            <table class="table shedontknow border12">
              <thead>
                <tr class="table-primary">
                  <th scope="col-2 contbox">Employee Code</th>
                  <th class="col-4">2012012012</th>

                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="col-2">Mobile Number</th>
                  <td class="col-4 ">8859932237</td>

                </tr>

              </tbody>
            </table>

          </div>
        </div>
      </div>

      <table class="table my-5 border12">
        <thead>
          <tr>
            <th scope="col">Current Date & Time</th>
            <td class="table-primary">6/7/23    5:30pm</td>

          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">Current Laltitude</th>
            <td class="table-primary">80.258874131654</td>

          </tr>
          <tr>
            <th scope="row">Current Longtitude</th>
            <td class="table-primary">70.2588745874158</td>

          </tr>
          <tr>
            <th scope="row">Accuracy</th>
            <td class="table-primary">98.3%</td>

          </tr>
          <tr>
            <th scope="row">Distance (Meter)</th>
            <td class="table-primary">95 M</td>

          </tr>
          <tr>
            <th scope="row">Remark</th>
            <td><input type="text" className="inputinner"></input></td>

          </tr>
          <tr>
            <th scope="row"></th>
            <div class="container">
              <div class="row">
                <div class="col-6 px-5 punchbtn"><i class="bi bi-telegram"></i>  Punch Out</div>
                <div class="col-6 px-5 btn23"> <i class="bi bi-geo-alt-fill"></i>  Get Current Location
                </div></div>

            </div>


          </tr>
        </tbody>
      </table>

    </>
  )

}